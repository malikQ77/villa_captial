namespace Core.ServicesInitializer;

using Auth;
using Messages;
using RabbitMQ.Client;
using Serilog.Context;
using Microsoft.Extensions.Configuration;
using Exceptions;
using Logging;
using Configurations;
using Database;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Serilog;

public static class ServiceInitializer
{
    public static void Initialize<T>(WebApplicationBuilder builder, string appSettingsPath, string secretsPath)
        where T : class, new()
    {
        builder.Services.AddAppConfig<T>(appSettingsPath, secretsPath);

        LogConfigurator.ConfigureLogger(builder.Configuration, builder.Logging);

        builder.WebHost.ConfigureKestrel(serverOptions =>
        {
            var kestrelConfig = builder.Configuration.GetSection(typeof(T).Name + ":Kestrel");
            var url = kestrelConfig.GetValue<string>("Url");

            if (string.IsNullOrEmpty(url))
            {
                throw new InvalidOperationException(
                    $"Kestrel URL configuration is missing in {typeof(T).Name}. Please ensure the 'Kestrel:Url' configuration is present in the appsettings file.");
            }

            builder.WebHost.UseUrls(url);
            serverOptions.AddServerHeader = false;
        });
        
        RegisterDatabaseServices(builder);
        RegisterRabbitMQServices(builder);
        builder.Services.AddControllers();
    }


    private static void RegisterDatabaseServices(WebApplicationBuilder builder)
    {
        builder.Services.AddSingleton(typeof(DapperRepository<>));
    }

    private static void RegisterRabbitMQServices(WebApplicationBuilder builder)
    {
        var factory = new ConnectionFactory
        {
            // from configs  
            HostName =  "localhost",
            Port =  5672,
            UserName = "guest",
            Password = "guest"
        };

        builder.Services.AddSingleton<IConnection>(_ =>
        {
            try
            {
                var connection = factory.CreateConnection();

                using (var model = connection.CreateModel())
                {
                    var rabbitMQSetup = new RabbitMQSetup(model);
                    rabbitMQSetup.SetupInfrastructure();
                }

                return connection;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Unable to establish RabbitMQ connection.", ex);
            }
        });

        builder.Services.AddScoped<IModel>(provider =>
        {
            var rabbitConnection = provider.GetRequiredService<IConnection>();
            return rabbitConnection.CreateModel();
        });

        builder.Services.AddScoped<MessageHandler>();
    }

    public static void Configure(WebApplication app)
    {
        var serviceName = app.Environment.ApplicationName;
        var serviceEnv = app.Environment.EnvironmentName;

        app.Use(async (context, next) =>
        {
            var traceId = Guid.NewGuid().ToString();
            context.Response.Headers.Add("X-Trace-ID", traceId);
            using (LogContext.PushProperty("TraceIdentifier", traceId))
            {
                await next.Invoke();
            }
        });

        app.UseExceptionHandling();

        app.UseMiddleware<AuthMiddleware>();

        app.MapControllers();

        Log.Information($"{serviceName} Started - {serviceEnv} Environment ...");

        app.Run();

        Log.Information($"{serviceName} Stopped ...");

        LogConfigurator.CloseAndFlushLogger();
    }
}