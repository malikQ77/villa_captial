using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Core.Exceptions;
using Microsoft.IdentityModel.Tokens;
using Serilog;

namespace Core.Utilities;

public static class JwtHelper
{
    public static string GenerateToken(Guid tokenId, string secretKey, int expireMinutes = 30)
    {
        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.ASCII.GetBytes(secretKey);

        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[]
            {
                new Claim("id", tokenId.ToString())
            }),
            Expires = DateTime.UtcNow.AddMinutes(expireMinutes),
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }

    public static ClaimsPrincipal ValidateToken(string token, string secretKey)
    {
        var tokenHandler = new JwtSecurityTokenHandler();
        var key = Encoding.ASCII.GetBytes(secretKey);

        try
        {
            return tokenHandler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = false, 
                ValidateAudience = false,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero
            }, out SecurityToken validatedToken);
        }
        catch (SecurityTokenExpiredException ex)
        {
            throw new VillaCapitalException(ExceptionDetails.UnauthorizedAccess);
        }
        catch (SecurityTokenInvalidSignatureException ex)
        {
            throw new VillaCapitalException(ExceptionDetails.UnauthorizedAccess);
        }
        catch (SecurityTokenInvalidIssuerException ex)
        {
            throw new VillaCapitalException(ExceptionDetails.UnauthorizedAccess);
        }
        catch (SecurityTokenInvalidAudienceException ex)
        {
            throw new VillaCapitalException(ExceptionDetails.UnauthorizedAccess);
        }
        catch (SecurityTokenValidationException ex)
        {
            throw new VillaCapitalException(ExceptionDetails.UnauthorizedAccess);
        }
        catch (Exception ex)
        {
            Log.Error(ex.Message);
            throw new VillaCapitalException(ExceptionDetails.UnauthorizedAccess);
        }
    }



    public static Guid? GetTokenIdFromJwt(string token, string secretKey)
    {
        var principal = ValidateToken(token, secretKey);
        return new Guid(principal?.FindFirst("id")?.Value);
    }
}