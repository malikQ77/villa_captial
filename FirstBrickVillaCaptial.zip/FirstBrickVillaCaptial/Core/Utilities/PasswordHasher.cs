using System.Security.Cryptography;
using System.Text;

namespace Core.Utilities;

public static class PasswordHasher
{
    public static string HashPassword(this string password, string salt)
    {
        var sha256 = SHA256.Create();
        var saltedPassword = password + salt;
        var saltedPasswordBytes = Encoding.UTF8.GetBytes(saltedPassword);
        var hashBytes = sha256.ComputeHash(saltedPasswordBytes);
        return Convert.ToBase64String(hashBytes);
    }

    public static bool VerifyPassword(this string password, string salt, string hash)
    {
        var hashedPassword = HashPassword(password, salt);
        return hashedPassword == hash;
    }
}