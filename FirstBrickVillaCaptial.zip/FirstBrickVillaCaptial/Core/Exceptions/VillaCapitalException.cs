namespace Core.Exceptions;

public class VillaCapitalException : Exception
{
    public readonly ExceptionDetails Details;

    public VillaCapitalException(ExceptionDetails exceptionDetails) 
        : base(exceptionDetails.GetExceptionDetails()?.ErrorMessage)
    {
        Details = exceptionDetails;
    }

    public VillaCapitalException(ExceptionDetails exceptionDetails, string customMessage) 
        : base(customMessage)
    {
        Details = exceptionDetails;
    }
    
}
