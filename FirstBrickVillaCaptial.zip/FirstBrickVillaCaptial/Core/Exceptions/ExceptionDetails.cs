namespace Core.Exceptions;

public enum ExceptionDetails
{
    [ExceptionDetailsAttributes( "V001", "Username is empty or Invalid", 400)]
    InvalidUsername,
    
    [ExceptionDetailsAttributes("V002", "Password is empty or Invalid", 400)]
    InvalidPassword,
    
    [ExceptionDetailsAttributes("V003", "Fullname is empty or Invalid", 400)]
    InvalidName,
    
    [ExceptionDetailsAttributes("V004", "Username already exist", 400)]
    UsernameExist,
    
    [ExceptionDetailsAttributes("V005", "Invalid Username or Password", 400)]
    InvalidUsernameOrPassword,
    
    [ExceptionDetailsAttributes("V006", "User account suspended", 400)]
    AccountSuspended,
    
    [ExceptionDetailsAttributes("V007", "Unauthorized Access", 401)]
    UnauthorizedAccess,
    
    [ExceptionDetailsAttributes("V008", "Insufficient balance", 400)]
    InsufficientBalance,
    
    [ExceptionDetailsAttributes("V009", "Data Not Available", 400)]
    DataNotAvailable,

    [ExceptionDetailsAttributes("S404", "Resource not found.", 404)]
    ResourceNotFound,
    
    [ExceptionDetailsAttributes("S500", "Unknown Server Error", 500)]
    UnknownServerError, // unkowon server error
    
    
}