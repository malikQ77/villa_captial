using System.Reflection;

namespace Core.Exceptions;


[AttributeUsage(AttributeTargets.Field, AllowMultiple = true)]
public sealed class ExceptionDetailsAttributes : Attribute
{
    public string ErrorCode { get; set; }
    public string ErrorMessage { get; set; }
    public int ResponseStatusCode { get; set; }

    public ExceptionDetailsAttributes( string errorCode,  string errorMessage, int responseStatusCode)
    {
        ErrorCode = errorCode;
        ErrorMessage = errorMessage;
        ResponseStatusCode = responseStatusCode;
    }
}


public static class ExceptionDetailsExtensions
{
    public static ExceptionDetailsAttributes? GetExceptionDetails(this ExceptionDetails exceptionDetails)
    {
        return (ExceptionDetailsAttributes?)exceptionDetails.GetType()
            .GetField(exceptionDetails.ToString())?
            .GetCustomAttribute(typeof(ExceptionDetailsAttributes), false);
    }
}