using Serilog;
namespace Core.Exceptions;

using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;

    public ExceptionHandlingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        try
        {
            await _next(context);
            
            if (context.Response.StatusCode == StatusCodes.Status404NotFound)
                throw new VillaCapitalException(ExceptionDetails.ResourceNotFound);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(context, ex);
        }
    }

    private static Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        ExceptionDetailsAttributes exceptionDetails;

        if (exception is VillaCapitalException villaCapitalException)
        {
            exceptionDetails = villaCapitalException.Details.GetExceptionDetails()!;
            Log.Information($"{exceptionDetails.ErrorCode} | {exceptionDetails.ErrorMessage} | {exceptionDetails.ResponseStatusCode}");
        }
        else
        {
            exceptionDetails = new VillaCapitalException(ExceptionDetails.UnknownServerError).Details.GetExceptionDetails()!;
            Log.Error($"{exception.Message } {exception.StackTrace}");
        }
        
        context.Response.ContentType = "application/json";
        context.Response.StatusCode = exceptionDetails!.ResponseStatusCode;

        return context.Response.WriteAsync(JsonSerializer.Serialize(new
        {
            errCode = exceptionDetails.ErrorCode,
            errMsg = exceptionDetails.ErrorMessage
        }));
    }
}

public static class ExceptionHandlingMiddlewareExtensions
{
    public static IApplicationBuilder UseExceptionHandling(this IApplicationBuilder builder)
    {
        return builder.UseMiddleware<ExceptionHandlingMiddleware>();
    }
}