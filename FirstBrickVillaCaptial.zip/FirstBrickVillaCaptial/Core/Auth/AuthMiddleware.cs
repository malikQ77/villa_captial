namespace Core.Auth;
using System.Text.Json;
using Exceptions;
using Messages;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Utilities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

public class AuthMiddleware
{
    private readonly RequestDelegate _next;
    private readonly string _secretKey;
    private readonly IServiceProvider _serviceProvider;


    public AuthMiddleware(RequestDelegate next, IConfiguration configuration, IServiceProvider serviceProvider)
    {
        _next = next;
        _secretKey = configuration["AppConfigs:JwtSecretKey"];
        _serviceProvider = serviceProvider;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Path.Value is "/v1/user" or "/v1/login")
            await _next(context);

        var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();

        if (token == null)
            throw new VillaCapitalException(ExceptionDetails.ResourceNotFound); // add unauthorized 

        var tokenId = JwtHelper.GetTokenIdFromJwt(token, _secretKey); // fix

        using (var scope = _serviceProvider.CreateScope())
        {
            var messageHandler = scope.ServiceProvider.GetRequiredService<MessageHandler>();
            try
            {
                Log.Information("Sending token validation request.");

                var response = await messageHandler.PublishMessageAndWaitForResponse(
                    new { TokenId = tokenId },
                    "token_validation_exchange",
                    "validate_token",
                    TimeSpan.FromSeconds(3)
                );

                if (string.IsNullOrEmpty(response))
                    throw new Exception("No response received from the token validation service.");

                var tokenValidationResponse = JsonSerializer.Deserialize<TokenValidationResponse>(response);

                if (tokenValidationResponse?.IsValid == true)
                {
                    Log.Information("Token is valid.");
                    await _next(context);
                }
                else
                {
                    throw new VillaCapitalException(ExceptionDetails.UnauthorizedAccess);
                }
            }
            catch (TimeoutException ex)
            {
                Log.Error("Token validation request timed out: {ExceptionMessage}", ex.Message);
                throw;
            }
            catch (JsonException ex)
            {
                Log.Error("Error parsing the token validation response: {ExceptionMessage}", ex.Message);
                throw;
            }
            catch (Exception ex) when (ex is not VillaCapitalException)
            {
                Log.Error("An unexpected error occurred during token validation: {ExceptionMessage}", ex.Message);
                throw;
            }
        }
    }
}

public class TokenValidationResponse
{
    public bool IsValid { get; set; }
}