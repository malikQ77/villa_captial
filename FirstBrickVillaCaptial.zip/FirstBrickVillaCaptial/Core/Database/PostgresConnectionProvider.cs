using System.Data;
using Npgsql;

namespace Core.Database;

public static class PostgresConnectionProvider
{
    public static IDbConnection CreateConnection(string connectionString)
    {
        return new NpgsqlConnection(connectionString);
    }
}