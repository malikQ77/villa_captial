namespace Core.Database;

using System.Data;
using Dapper;
using Npgsql;
public class DapperRepository<T> where T : class
{
    private readonly string _connectionString;

    public DapperRepository(string connectionString)
    {
        _connectionString = connectionString;
    }

    private IDbConnection CreateConnection()
    {
        return new NpgsqlConnection(_connectionString);
    }
    
    public async Task<IEnumerable<TResult>> GetAllAsync<TResult>(string query)
    {
        using (var connection = CreateConnection())
        {
            return await connection.QueryAsync<TResult>(query);
        }
    }
    
    public async Task<IEnumerable<TResult>> GetAllAsync<TResult>(string query, object parameters)
    {
        using (var connection = CreateConnection())
        {
            return await connection.QueryAsync<TResult>(query, parameters);
        }
    }

    public async Task<TResult?> GetByFirstOrDefault<TResult>(string query, object parameters)
    {
        using (var connection = CreateConnection())
        {
            return await connection.QueryFirstOrDefaultAsync<TResult>(query, parameters);
        }
    }
    
    public async Task<TResult?> GetBySingleOrDefaultAsync<TResult>(string query, object parameters)
    {
        using (var connection = CreateConnection())
        {
            return await connection.QuerySingleOrDefaultAsync<TResult>(query, parameters);
        }
    }
    
    public async Task<int> ExecuteAsync(string query, object parameters)
    {
        using (var connection = CreateConnection())
        {
            return await connection.ExecuteAsync(query, parameters);
        }
    }
    
    public async Task<TResult?> ExecuteScalarAsync<TResult>(string query, object parameters)
    {
        using (var connection = CreateConnection())
        {
            return await connection.ExecuteScalarAsync<TResult>(query, parameters);
        }
    }
}