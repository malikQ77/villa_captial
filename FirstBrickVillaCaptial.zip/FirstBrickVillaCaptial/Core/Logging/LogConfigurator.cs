using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;

namespace Core.Logging;

public static class LogConfigurator
{
    public static void ConfigureLogger(IConfiguration configuration, ILoggingBuilder builderLogging)
    {
        builderLogging.ClearProviders();
        
        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .Enrich.FromLogContext()
            .CreateLogger();
        
        Log.Information("Logger Initialized ...");
    }

    public static void CloseAndFlushLogger()
    {
        Log.CloseAndFlush();
    }
}