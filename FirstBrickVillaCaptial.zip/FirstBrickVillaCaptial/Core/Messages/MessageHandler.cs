namespace Core.Messages;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

public class MessageHandler
{
    private readonly IModel _channel;
    private string _replyQueueName;
    private EventingBasicConsumer _syncConsumer;
    private TaskCompletionSource<string> _responseTaskSource;
    private string _correlationId;

    public MessageHandler(IModel channel)
    {
        _channel = channel;
        InitializeReplyQueue();
    }

    private void InitializeReplyQueue()
    {
        _replyQueueName = _channel.QueueDeclare().QueueName;

        _syncConsumer = new EventingBasicConsumer(_channel);
        _syncConsumer.Received += (model, ea) =>
        {
            if (ea.BasicProperties.CorrelationId == _correlationId)
            {
                var response = Encoding.UTF8.GetString(ea.Body.ToArray());
                _responseTaskSource.SetResult(response);
            }
        };

        _channel.BasicConsume(queue: _replyQueueName, autoAck: true, consumer: _syncConsumer);
    }

    public void PublishMessage<T>(T message, string exchange, string routingKey)
    {
        if (string.IsNullOrEmpty(routingKey))
        {
            throw new ArgumentNullException(nameof(routingKey), "Routing key cannot be null or empty.");
        }

        var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(message));
        var properties = _channel.CreateBasicProperties();
        properties.Persistent = true;

        _channel.BasicPublish(exchange: exchange, routingKey: routingKey, basicProperties: properties, body: body);
    }


    public Task<string> PublishMessageAndWaitForResponse<T>(T message, string exchange, string routingKey, TimeSpan timeout)
    {
        _correlationId = Guid.NewGuid().ToString(); 
        _responseTaskSource = new TaskCompletionSource<string>();

        var properties = _channel.CreateBasicProperties();
        properties.CorrelationId = _correlationId;
        properties.ReplyTo = _replyQueueName;

        var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(message));

        _channel.BasicPublish(exchange: exchange, routingKey: routingKey, basicProperties: properties, body: body);

        var task = _responseTaskSource.Task;
        if (Task.WhenAny(task, Task.Delay(timeout)).Result == task)
        {
            return task;
        }
        else
        {
            throw new TimeoutException("No response received within the timeout period.");
        }
    }


    public void ConsumeMessages(string queue, Func<BasicDeliverEventArgs, Task> onMessageReceived)
    {
        var consumer = new EventingBasicConsumer(_channel);
        consumer.Received += async (model, ea) =>
        {
            await onMessageReceived(ea);
        };

        _channel.BasicConsume(queue: queue, autoAck: true, consumer: consumer);
    }

}
