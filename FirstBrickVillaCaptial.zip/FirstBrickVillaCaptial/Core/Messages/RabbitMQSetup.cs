using RabbitMQ.Client;

namespace Core.Messages;

public class RabbitMQSetup
{
    private readonly IModel _channel;

    public RabbitMQSetup(IModel channel)
    {
        _channel = channel;
    }

    public void SetupInfrastructure()
    {
        _channel.ExchangeDeclare(exchange: "token_validation_exchange", type: ExchangeType.Direct, durable: true, autoDelete: false, arguments: null);
        _channel.QueueDeclare(queue: "validate_token_queue", durable: true, exclusive: false, autoDelete: false, arguments: null);
        _channel.QueueBind(queue: "validate_token_queue", exchange: "token_validation_exchange", routingKey: "validate_token");

        _channel.ExchangeDeclare(exchange: "balance_validation_exchange", type: "direct", durable: true, autoDelete: false, arguments: null);
        _channel.QueueDeclare(queue: "validate_balance_queue", durable: true, exclusive: false, autoDelete: false, arguments: null);
        _channel.QueueBind(queue: "validate_balance_queue", exchange: "balance_validation_exchange", routingKey: "validate_balance", arguments: null);
        
        _channel.ExchangeDeclare(exchange: "user_portfolio_exchange", type: "direct", durable: true, autoDelete: false, arguments: null);
        _channel.QueueDeclare(queue: "get_user_portfolio_queue", durable: true, exclusive: false, autoDelete: false, arguments: null);
        _channel.QueueBind(queue: "get_user_portfolio_queue", exchange: "user_portfolio_exchange", routingKey: "get_user_portfolio", arguments: null);
        
        _channel.ExchangeDeclare(exchange: "get_project_details_exchange", type: "direct", durable: true, autoDelete: false, arguments: null);
        _channel.QueueDeclare(queue: "get_project_details_queue", durable: true, exclusive: false, autoDelete: false, arguments: null);
        _channel.QueueBind(queue: "get_project_details_queue", exchange: "get_project_details_exchange", routingKey: "get_project_details", arguments: null);
        
        _channel.ExchangeDeclare(exchange: "balance_deduction_exchange", type: "direct", durable: true, autoDelete: false, arguments: null);
        _channel.QueueDeclare(queue: "reduce_balance_queue", durable: true, exclusive: false, autoDelete: false, arguments: null);
        _channel.QueueBind(queue: "reduce_balance_queue", exchange: "balance_deduction_exchange", routingKey: "reduce_balance", arguments: null);
    }
}