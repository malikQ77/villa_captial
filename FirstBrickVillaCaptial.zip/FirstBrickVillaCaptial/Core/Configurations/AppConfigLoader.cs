using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Core.Configurations;

public static class AppConfigLoader
{
    public static T AddAppConfig<T>(this IServiceCollection services, string configFilePath, string secretsFilePath )
        where T : class, new()
    {
        if (!File.Exists(configFilePath))
            throw new FileNotFoundException($"Configuration file not found at path: {configFilePath}");

        if (!File.Exists(secretsFilePath))
            throw new FileNotFoundException($"Secrets file not found at path: {configFilePath}");

        var configuration = new ConfigurationBuilder()
            .AddJsonFile(configFilePath, optional: false, reloadOnChange: false)
            .AddJsonFile(secretsFilePath, optional: true, reloadOnChange: false)
            .Build();

        var appConfig = new T();
        configuration.GetSection(typeof(T).Name).Bind(appConfig);

        services.AddSingleton(appConfig);
        return appConfig;
    }
}