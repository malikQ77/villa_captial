using System.Text.RegularExpressions;

namespace Core.Validators;

public class Validators
{
    public static bool IsValidUsername(string username)
    {
        Regex usernameRegex = new Regex(@"^[a-zA-Z0-9]+$");
        
        if (string.IsNullOrEmpty(username) || username.Length < 6)
            return false;

        return usernameRegex.IsMatch(username);
    }
    
    
    public static bool IsValidPassword(string password)
    {
        Regex passwordRegex = new Regex(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$");
        if (string.IsNullOrEmpty(password))
            return false;

        return passwordRegex.IsMatch(password);
    }
}