using Core.ServicesInitializer;
using InvestmentService.BusinessLogic;
using PaymentService.BusinessLogic;
using PaymentService.DataAccess;

string appSettingsPath = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
string secretsPath = Path.Combine(Directory.GetCurrentDirectory(), "secrets.json");


var builder = WebApplication.CreateBuilder(args);
ServiceInitializer.Initialize<AppConfigs>(builder, appSettingsPath, secretsPath);

builder.Services.AddSingleton<PaymentServiceLogic>();
builder.Services.AddSingleton<PaymentServiceRepository>();
builder.Services.AddTransient<BalanceListeners>();
builder.Services.AddHostedService<RabbitMqListenerService>();

var app = builder.Build();
ServiceInitializer.Configure(app);