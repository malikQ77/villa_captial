namespace PaymentService.Models;

public class PaginatedTransactions
{
    public int TotalCount { get; set; }
    public IEnumerable<Transaction> Transactions { get; set; }
}