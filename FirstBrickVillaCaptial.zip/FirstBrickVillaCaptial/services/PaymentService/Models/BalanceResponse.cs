namespace PaymentService.Models;

public class BalanceResponse
{
    public string Username { get; set; }
    public decimal Balance { get; set; }
}