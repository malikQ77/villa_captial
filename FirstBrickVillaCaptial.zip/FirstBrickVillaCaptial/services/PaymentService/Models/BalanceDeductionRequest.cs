namespace PaymentService.Models;

public class BalanceDeductionRequest
{
    public string Username { get; set; }
    public decimal AmountToDeduct { get; set; }
}