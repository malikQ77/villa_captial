namespace PaymentService.Models;

public class TopUpRequest
{
    public string Username { get; set; }
    public decimal Amount { get; set; }
}

public class TopUpResponse
{
    public bool Status { get; set; }
}