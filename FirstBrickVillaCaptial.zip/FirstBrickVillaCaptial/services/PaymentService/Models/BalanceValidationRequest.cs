namespace PaymentService.Models;

public class BalanceValidationRequest
{
    public string Username { get; set; }
    public decimal AmountRequested { get; set; }
}