using System.Text;
using System.Text.Json;
using Core.Messages;
using PaymentService.DataAccess;
using PaymentService.Models;
using RabbitMQ.Client;
using Serilog;

namespace PaymentService.BusinessLogic;

public class BalanceListeners
{
    private readonly PaymentServiceRepository _paymentRepository;
    private readonly MessageHandler _messageHandler;
    private readonly IModel _channel;

    public BalanceListeners(MessageHandler messageHandler, IModel channel, PaymentServiceRepository paymentRepository)
    {
        _messageHandler = messageHandler;
        _channel = channel;
        _paymentRepository = paymentRepository;
    }

    public void StartListeningForBalanceValidationRequests()
    {
        _messageHandler.ConsumeMessages("validate_balance_queue", async (ea) =>
        {
            var messageBody = Encoding.UTF8.GetString(ea.Body.ToArray());
            var balanceRequest = JsonSerializer.Deserialize<BalanceValidationRequest>(messageBody);

            Log.Information($"Received balance validation request for Username: {balanceRequest.Username}");

            var balance = await _paymentRepository.GetUserBalance(balanceRequest.Username);

            var isValid = balance >= balanceRequest.AmountRequested;

            var replyTo = ea.BasicProperties.ReplyTo;
            var correlationId = ea.BasicProperties.CorrelationId;

            if (string.IsNullOrEmpty(replyTo))
            {
                throw new ArgumentNullException(nameof(replyTo), "ReplyTo cannot be null or empty.");
            }

            var response = new { IsValid = isValid };
            var responseBody = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(response));

            var responseProperties = _channel.CreateBasicProperties();
            responseProperties.CorrelationId = correlationId;

            _channel.BasicPublish(exchange: "", routingKey: replyTo, basicProperties: responseProperties, body: responseBody);

           Log.Information($"Balance validation response sent to ReplyTo queue: {replyTo}");
        });
    }
    
    public void StartListeningForBalanceDeductionRequests()
    {
        _messageHandler.ConsumeMessages("reduce_balance_queue", async (ea) =>
        {
            var messageBody = Encoding.UTF8.GetString(ea.Body.ToArray());
            var deductionRequest = JsonSerializer.Deserialize<BalanceDeductionRequest>(messageBody);

            if (deductionRequest == null)
            {
                Console.WriteLine("Received invalid deduction request. Skipping.");
                return;
            }

           Log.Information($"Received balance deduction request for Username: {deductionRequest.Username}");

            await _paymentRepository.DeductUserBalance(deductionRequest.Username, deductionRequest.AmountToDeduct);
            return;
        });
    }

}
