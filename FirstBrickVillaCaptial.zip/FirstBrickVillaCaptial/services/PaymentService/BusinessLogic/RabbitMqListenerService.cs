using PaymentService.BusinessLogic;

namespace InvestmentService.BusinessLogic;


    public class RabbitMqListenerService : IHostedService
    {
        private readonly IServiceProvider _serviceProvider;

        public RabbitMqListenerService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            var scope = _serviceProvider.CreateScope();
            var balanceListeners = scope.ServiceProvider.GetRequiredService<BalanceListeners>();
            balanceListeners.StartListeningForBalanceValidationRequests();
            balanceListeners.StartListeningForBalanceDeductionRequests();
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }
