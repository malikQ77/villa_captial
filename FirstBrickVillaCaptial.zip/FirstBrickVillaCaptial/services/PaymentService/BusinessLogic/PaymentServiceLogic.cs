using PaymentService.DataAccess;
using PaymentService.Models;

namespace PaymentService.BusinessLogic;

public class PaymentServiceLogic
{
    private readonly PaymentServiceRepository _paymentRepository;

    public PaymentServiceLogic(PaymentServiceRepository paymentRepository)
    {
        _paymentRepository = paymentRepository;
    }

    public async Task<TopUpResponse> ApplePayTopUp(TopUpRequest request)
    {
        var result = await _paymentRepository.TopUpUserBalance(request.Username, request.Amount);
        return new TopUpResponse()
        {
            Status = result
        };
    }

    public async Task<BalanceResponse> GetUserBalance(string username)
    {
        var balance = await _paymentRepository.GetUserBalance(username);
        return new BalanceResponse
        {
            Username = username,
            Balance = balance
        };
    }

    public async Task<PaginatedTransactions> GetUserTransactions(string username, int page, int pageSize)
    {
        var transactions = await _paymentRepository.GetUserTransactions(username, page, pageSize);
        var totalCount = await _paymentRepository.GetTransactionCount(username);

        return new PaginatedTransactions
        {
            TotalCount = totalCount,
            Transactions = transactions
        };
    }
}
