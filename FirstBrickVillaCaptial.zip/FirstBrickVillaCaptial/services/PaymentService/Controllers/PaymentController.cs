using Microsoft.AspNetCore.Mvc;
using PaymentService.BusinessLogic;
using PaymentService.Models;

namespace PaymentService.Controllers;

[ApiController]
public class PaymentController : ControllerBase
{
    private readonly PaymentServiceLogic _paymentServiceLogic;

    public PaymentController(PaymentServiceLogic paymentServiceLogic)
    {
        _paymentServiceLogic = paymentServiceLogic;
    }

    // POST /v1/ApplepayTopup : Mock endpoint to add funds to the user's account
    [HttpPost("/v1/ApplepayTopup")]
    public async Task<IActionResult> ApplePayTopUp([FromBody] TopUpRequest topUpRequest)
    {
        try
        {
            var result = await _paymentServiceLogic.ApplePayTopUp(topUpRequest);
            return Ok(result);
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { Error = ex.Message });
        }
    }

    // GET /v1/balance : Returns the user's balance
    [HttpGet("/v1/balance")]
    public async Task<IActionResult> GetBalance([FromQuery] string username)
    {
        try
        {
            var balanceResponse = await _paymentServiceLogic.GetUserBalance(username);
            return Ok(balanceResponse);
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { Error = ex.Message });
        }
    }

    // GET /v1/transactions : Returns a paginated list of the user's transactions
    [HttpGet("/v1/transactions")]
    public async Task<IActionResult> GetTransactions([FromQuery] string username, [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
    {
        try
        {
            var paginatedTransactions = await _paymentServiceLogic.GetUserTransactions(username, page, pageSize);
            return Ok(paginatedTransactions);
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { Error = ex.Message });
        }
    }
}
