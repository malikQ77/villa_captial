using Core.Database;
using PaymentService.Models;

namespace PaymentService.DataAccess;

public class PaymentServiceRepository : DapperRepository<PaymentServiceRepository>
{
    private readonly AppConfigs _appConfigs;

    public PaymentServiceRepository(AppConfigs appConfigs) : base(appConfigs.DbConnectionString)
    {
        _appConfigs = appConfigs;
    }

    public async Task<bool> TopUpUserBalance(string username, decimal amount)
    {
        string ensureUserQuery = @"
        INSERT INTO users_balance (username, balance)
        SELECT @username, 0
        WHERE NOT EXISTS (SELECT 1 FROM users_balance WHERE username = @username);";


        string query = @"
            INSERT INTO transactions (transaction_id, username, amount, transaction_date)
            VALUES (gen_random_uuid(), @username, @Amount, NOW());

            UPDATE users_balance
            SET balance = balance + @Amount
            WHERE username = @username;
        ";

        return (await ExecuteAsync(ensureUserQuery, new { username }) +
                await ExecuteAsync(query, new { username, Amount = amount })) == 2;
    }

    public async Task<decimal> GetUserBalance(string username)
    {
        string query = "SELECT balance FROM users_balance WHERE username = @username;";
        return await ExecuteScalarAsync<decimal>(query, new { username });
    }

    public async Task<IEnumerable<Transaction>> GetUserTransactions(string username, int page, int pageSize)
    {
        string query = @"
            SELECT transaction_id as TransactionId, amount, username, transaction_date as TransactionDate FROM transactions
            WHERE username = @username
            ORDER BY transaction_date DESC
            LIMIT @PageSize OFFSET @Offset;
        ";

        return await GetAllAsync<Transaction>(query, new
        {
            username,
            PageSize = pageSize,
            Offset = (page - 1) * pageSize
        });
    }

    public async Task<int> GetTransactionCount(string username)
    {
        string query = "SELECT COUNT(1) FROM transactions WHERE username = @username;";
        return await ExecuteScalarAsync<int>(query, new { username });
    }
    
    public async Task<int> DeductUserBalance(string username, decimal amount)
    {
        string query = @"
            UPDATE users_balance
            SET balance = balance - @Amount
            WHERE username = @username AND balance >= @amount;
        ";

        return await ExecuteAsync(query, new { username, amount });
    }
}