using AccountService.BusinessLogic;
using AccountService.Models;
using Microsoft.AspNetCore.Mvc;

namespace AccountService.Controllers;


[ApiController]
public class AccountController : ControllerBase
{
    private readonly AccountServiceLogic _accountServiceLogic;

    public AccountController(AccountServiceLogic accountServiceLogic)
    {
        _accountServiceLogic = accountServiceLogic;
    }

    [HttpPost("/v1/user")]
    public async Task<IActionResult> Registration([FromBody] RegistrationRequest registrationRequest)
    {
        return Ok(await _accountServiceLogic.RegisterNewUser(registrationRequest));
    }
    
    [HttpPost("/v1/login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest loginRequest)
    {
        return Ok(await _accountServiceLogic.UserLogin(loginRequest));
    }
    
    [HttpGet("/v1/{username}")]
    public async Task<IActionResult> GetUserProfileInfo(string username)
    {
        return Ok(await _accountServiceLogic.UserProfileInfo(username));
    }
    
    [HttpPut("/v1/{username}")]
    public async Task<IActionResult> UpdateUserProfileInfo([FromRoute] string username, [FromBody] UpdateUserProfileRequest updateUserProfileRequest)
    {
        return Ok(await _accountServiceLogic.UpdateUserProfileInfo(username, updateUserProfileRequest));
    }
    
}

