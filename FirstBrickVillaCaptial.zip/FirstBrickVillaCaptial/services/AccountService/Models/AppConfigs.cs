namespace AccountService;

public class AppConfigs
{
    public string JwtSecretKey { get; set; }
    public string DbConnectionString { get; set; }
}