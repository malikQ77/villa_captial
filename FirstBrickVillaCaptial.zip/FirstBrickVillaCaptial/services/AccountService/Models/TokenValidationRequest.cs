namespace AccountService.Models;

public class TokenValidationRequest
{
    public Guid TokenId { get; set; }
    public string CorrelationId { get; set; }
    public string ReplyTo { get; set; }
}