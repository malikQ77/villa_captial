using System.ComponentModel.DataAnnotations;
using Core.Exceptions;
using Core.Validators;

namespace AccountService.Models;

public class RegistrationRequest : IValidatableObject 
{
    public string Username { get; set; }
    public string Password { get; set; }
    public string FullName { get; set; }
    
    
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!Validators.IsValidUsername(Username))
            throw new VillaCapitalException(ExceptionDetails.InvalidUsername);
        
        if (!Validators.IsValidPassword(Password))
            throw new VillaCapitalException(ExceptionDetails.InvalidPassword);
        
        if(string.IsNullOrEmpty(FullName) || FullName.Length > 255)
            throw new VillaCapitalException(ExceptionDetails.InvalidName);
        
        return Enumerable.Empty<ValidationResult>();
    }
    
}

public class RegistrationResponse
{
    public bool Status { get; set; }
}
