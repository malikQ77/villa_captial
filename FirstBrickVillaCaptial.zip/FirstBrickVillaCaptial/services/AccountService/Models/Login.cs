namespace AccountService.Models;

using System.ComponentModel.DataAnnotations;
using Core.Exceptions;
using Core.Validators;

public class LoginRequest : IValidatableObject
{
    public string Username { get; set; }
    public string Password { get; set; }
    
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!Validators.IsValidUsername(Username))
            throw new VillaCapitalException(ExceptionDetails.InvalidUsername);
        
        if (!Validators.IsValidPassword(Password))
            throw new VillaCapitalException(ExceptionDetails.InvalidPassword);

        return Enumerable.Empty<ValidationResult>();
    }
}


public class LoginResponse
{
    public string Authorization { get; set; }
}