using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using Core.Exceptions;
using Core.Validators;

namespace AccountService.Models;

public class UserProfile
{
    public string Username { get; set; }

    [JsonIgnore] public string Password { get; set; }
    public string FullName { get; set; }
    [JsonIgnore] public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class UpdateUserProfileRequest : IValidatableObject
{
    public string Username { get; set; }
    public string FullName { get; set; }
    public string Password { get; set; }
    
    
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!Validators.IsValidUsername(Username))
            throw new VillaCapitalException(ExceptionDetails.InvalidUsername);
        
        if (!Validators.IsValidPassword(Password))
            throw new VillaCapitalException(ExceptionDetails.InvalidPassword);
        
        if(string.IsNullOrEmpty(FullName) || FullName.Length > 255)
            throw new VillaCapitalException(ExceptionDetails.InvalidName);
        
        return Enumerable.Empty<ValidationResult>();
    }

}

public class UpdateUserProfileResponse
{
    public bool Status { get; set; }
}