namespace AccountService.BusinessLogic;

using System.Transactions;
using DataAccess;
using Models;
using Core.Exceptions;
using Core.Utilities;

public class AccountServiceLogic
{
    private readonly AppConfigs _appConfigs;
    private readonly AccountServiceRepository _accountServiceRepository;

    public AccountServiceLogic(AccountServiceRepository accountServiceRepository, AppConfigs appConfigs)
    {
        _accountServiceRepository = accountServiceRepository;
        _appConfigs = appConfigs;
    }

    public async Task<RegistrationResponse> RegisterNewUser(RegistrationRequest registrationRequest)
    {
        if (await _accountServiceRepository.UsernameExists(registrationRequest.Username))
            throw new VillaCapitalException(ExceptionDetails.UsernameExist);

        var hashedPassword = registrationRequest.Password.HashPassword(
            salt: registrationRequest.Username + registrationRequest.FullName);

        return new RegistrationResponse()
        {
            Status = await _accountServiceRepository.InsertNewUser(
                registrationRequest.Username,
                hashedPassword,
                registrationRequest.FullName)
        };
    }

    public async Task<LoginResponse> UserLogin(LoginRequest loginRequest)
    {
        var userProfile = await _accountServiceRepository.GetUserProfileInfo(loginRequest.Username);

        if (userProfile is null ||
            !loginRequest.Password.VerifyPassword(salt: userProfile.Username + userProfile.FullName,
                userProfile.Password))
            throw new VillaCapitalException(ExceptionDetails.InvalidUsernameOrPassword);

        if (!userProfile.IsActive)
            throw new VillaCapitalException(ExceptionDetails.AccountSuspended);

        var tokenId = Guid.NewGuid();
        string jwt;

        using (var transactionScope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
        {
            await _accountServiceRepository.InvalidateUserTokenByUsername(userProfile.Username);
            await _accountServiceRepository.InsertNewTokenId(tokenId, userProfile.Username);
            
            jwt = JwtHelper.GenerateToken(tokenId, _appConfigs.JwtSecretKey, 60);
            transactionScope.Complete();
        }

        return new LoginResponse()
        {
            Authorization = jwt
        };
    }

    public async Task<UserProfile> UserProfileInfo(string username) =>
        await _accountServiceRepository.GetUserProfileInfo(username) ??
        throw new VillaCapitalException(ExceptionDetails.InvalidUsername);


    public async Task<object?> UpdateUserProfileInfo(string username, UpdateUserProfileRequest updateUserProfileRequest)
    {
        var userProfile = await _accountServiceRepository.GetUserProfileInfo(username);

        if (userProfile is null || username == updateUserProfileRequest.Username)
            throw new VillaCapitalException(ExceptionDetails.InvalidUsername);

        if (await _accountServiceRepository.UsernameExists(updateUserProfileRequest.Username))
            throw new VillaCapitalException(ExceptionDetails.UsernameExist);

        var hashedPassword = updateUserProfileRequest.Password.HashPassword(
            salt: updateUserProfileRequest.Username + updateUserProfileRequest.FullName);

        return new UpdateUserProfileResponse()
        {
            Status = await _accountServiceRepository.UpdateUserProfileInfo(
                username,
                updateUserProfileRequest.Username,
                hashedPassword,
                updateUserProfileRequest.FullName)
        };
    }
}