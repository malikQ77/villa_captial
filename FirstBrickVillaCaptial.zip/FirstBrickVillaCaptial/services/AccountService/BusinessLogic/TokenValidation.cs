namespace AccountService.BusinessLogic;

using Models;
using Serilog;
using Core.Messages;
using RabbitMQ.Client;
using System.Text;
using System.Text.Json;
using DataAccess;

public class TokenValidation
    {
        private readonly MessageHandler _messageHandler;
        private readonly AccountServiceRepository _repository;
        private readonly IModel _channel;

        public TokenValidation(MessageHandler messageHandler, IModel channel, AccountServiceRepository repository)
        {
            _messageHandler = messageHandler;
            _channel = channel;
            _repository = repository;
        }

        public void StartListeningForTokenValidationRequests()
        {
            _messageHandler.ConsumeMessages("validate_token_queue", async (ea) =>
            {
                try
                {
                    var messageBody = Encoding.UTF8.GetString(ea.Body.ToArray());
                    var tokenValidationRequest = JsonSerializer.Deserialize<TokenValidationRequest>(messageBody);
                    var tokenId = tokenValidationRequest!.TokenId;

                    Log.Information("Received token validation request for TokenId: {TokenId}", tokenId);

                    var replyTo = ea.BasicProperties.ReplyTo;
                    var correlationId = ea.BasicProperties.CorrelationId;

                    if (string.IsNullOrEmpty(replyTo))
                    {
                        Log.Error("ReplyTo property is missing or empty. Unable to send response.");
                        throw new ArgumentNullException(nameof(replyTo), "ReplyTo cannot be null or empty.");
                    }

                    bool isValid = await _repository.ValidateTokenId(tokenId);

                    var response = new { IsValid = isValid };
                    var responseBody = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(response));

                    var responseProperties = _channel.CreateBasicProperties();
                    responseProperties.CorrelationId = correlationId;

                    _channel.BasicPublish(exchange: "", routingKey: replyTo, basicProperties: responseProperties, body: responseBody);

                    Log.Information("Response sent to ReplyTo queue: {ReplyTo}, CorrelationId: {CorrelationId}", replyTo, correlationId);
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "An error occurred while processing token validation request.");
                    throw;
                }
            });
        }
    }