namespace AccountService;

using BusinessLogic;

public class RabbitMqListenerService : IHostedService
{
    private readonly IServiceProvider _serviceProvider;

    public RabbitMqListenerService(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        var scope = _serviceProvider.CreateScope();
        var tokenValidationService = scope.ServiceProvider.GetRequiredService<TokenValidation>();
        tokenValidationService.StartListeningForTokenValidationRequests();
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }
}