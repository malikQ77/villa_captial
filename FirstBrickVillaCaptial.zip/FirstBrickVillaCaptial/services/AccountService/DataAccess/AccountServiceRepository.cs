using AccountService.Models;
using Core.Database;

namespace AccountService.DataAccess;

public class AccountServiceRepository : DapperRepository<AccountServiceRepository>
{

    public AccountServiceRepository(AppConfigs appConfigs) : base(appConfigs.DbConnectionString)
    {
    }

    public async Task<bool> UsernameExists(string username)
    {
        string query = @"
                        BEGIN;
                        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                        SELECT count(1) FROM users where username = @username;
                        COMMIT;
                        ";
        return await ExecuteScalarAsync<bool>(query, new { username });
    }
    
    public async Task<bool> InsertNewUser(string username, string password, string fullName)
    {
        string query = @"
                        INSERT INTO users
                        (username, password, full_name)
                        VALUES (@username, @password, @fullName);
                        ";
        return (await ExecuteAsync(query, new { username, password, fullName })) == 1;
    }
    
    public async Task<UserProfile?> GetUserProfileInfo(string username)
    {
        string query = @"
                        BEGIN;
                        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                        SELECT username, password, full_name as FullName, is_active as IsActive, created_at as CreatedAt 
                        FROM users where username = @username;
                        COMMIT;
                        ";
        return await GetBySingleOrDefaultAsync<UserProfile>(query, new { username });
    }
    
    public async Task<bool> UpdateUserProfileInfo(string oldUsername, string newUsername, string newPassword, string newName)
    {
        /*
            Please note: The `username` fields between `tokens_management.username` and `users.username` 
            may become inconsistent depending on business requirements.
            For example, if a username is updated or deleted in the `users` table, the corresponding 
            `username` in `tokens_management` may not be automatically updated and could become out of sync.
            If consistency between these values is a business need, an appropriate solution will be implemented.
        */
        string query = @"
                        UPDATE users
	                    SET username = @newUsername, password = @newPassword, full_name = @newName
	                    WHERE username = @oldUsername;
                        ";
        return (await ExecuteAsync(query, new { oldUsername, newUsername, newPassword, newName })) == 1;
    }
    public async Task<bool> InsertNewTokenId(Guid tokenId, string username)
    {
        string query = @"INSERT INTO tokens_management (token_id, username) VALUES (@tokenId, @username);";
        return (await ExecuteAsync(query, new { tokenId, username })) == 1;
    }


    public async Task<bool> InvalidateUserTokenByUsername(string username)
    {
        string query = @"UPDATE tokens_management
                         SET is_active = false, deactivation_at = now()
                         WHERE username = @username
                         AND is_active = true;";
        return (await ExecuteAsync(query, new { username })) == 1;
    }
    
    public async Task<bool> InvalidateUserTokenByTokenId(Guid tokenId)
    {
        string query = @"UPDATE tokens_management
                         SET is_active = false, deactivation_at = now()
                         WHERE token_id = @tokenId
                         AND is_active = true;";
        return (await ExecuteAsync(query, new { tokenId })) == 1;
    }
    
    public async Task<bool> ValidateTokenId(Guid tokenId)
    {
        var query = @"
                        BEGIN;
                        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                        SELECT COUNT(1) FROM tokens_management WHERE token_id = @tokenId AND is_active = true;
                        COMMIT;";
        return await ExecuteScalarAsync<bool>(query, new { tokenId });
    }
}