using AccountService;
using AccountService.BusinessLogic;
using AccountService.DataAccess;
using Core.ServicesInitializer;

// read from Args or Env variables if prod other from current directory
string appSettingsPath = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
string secretsPath = Path.Combine(Directory.GetCurrentDirectory(), "secrets.json");


var builder = WebApplication.CreateBuilder(args);
ServiceInitializer.Initialize<AppConfigs>(builder, appSettingsPath, secretsPath);

builder.Services.AddSingleton<AccountServiceLogic>();
builder.Services.AddSingleton<AccountServiceRepository>();
builder.Services.AddTransient<TokenValidation>();
builder.Services.AddHostedService<RabbitMqListenerService>();

var app = builder.Build();
ServiceInitializer.Configure(app);