using InvestmentService.BusinessLogic;

namespace InvestmentService.Controllers;

using Models;
using Microsoft.AspNetCore.Mvc;

[ApiController]
public class InvestmentController :ControllerBase
{
    private readonly InvestmentServiceLogic _investmentServiceLogic;

    public InvestmentController(InvestmentServiceLogic investmentServiceLogic)
    {
        _investmentServiceLogic = investmentServiceLogic;
    }

    [HttpPost("/v1/project")]
    public async Task<IActionResult> CreateProject([FromBody] Project createProjectRequest)
    {
        return Ok(await _investmentServiceLogic.CreateNewProject(createProjectRequest));
    }

    [HttpGet("/v1/projects")]
    public async Task<IActionResult> GetProjects()
    {
        return Ok(await _investmentServiceLogic.ViewAllProjects());
    }

    [HttpPost("/v1/invest")]
    public async Task<IActionResult> ContributeToProject([FromBody] InvestmentRequest investmentRequest)
    {
        return Ok(await _investmentServiceLogic.InvestInProject(investmentRequest));
    }
}