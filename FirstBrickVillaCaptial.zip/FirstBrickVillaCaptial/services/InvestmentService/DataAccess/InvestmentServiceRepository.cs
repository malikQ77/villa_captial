using Core.Database;
using InvestmentService.Models;

namespace InvestmentService.DataAccess;

public class InvestmentServiceRepository : DapperRepository<InvestmentServiceRepository>
{
    private readonly AppConfigs _appConfigs;

    public InvestmentServiceRepository(AppConfigs appConfigs) : base(appConfigs.DbConnectionString)
    {
        _appConfigs = appConfigs;
    }

    public async Task<bool> CreateProject(Project project)
    {
        string query = @"
            INSERT INTO projects
            (project_id, project_name, funding_goal, description, current_funding)
            VALUES (@ProjectId, @ProjectName, @FundingGoal, @Description, @CurrentFunding);";

        return (await ExecuteAsync(query, new 
        {
            project.ProjectId,
            project.ProjectName,
            project.FundingGoal,
            project.Description,
            project.CurrentFunding
        })) == 1;
    }

    public async Task<IEnumerable<Project>> GetAllProjects()
    {
        string query = @"
                        BEGIN;
                        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
                        SELECT project_id as ProjectId, project_name as ProjectName, funding_goal as FundingGoal, description, current_funding as CurrentFunding FROM projects;
                        COMMIT;
                        ";
        return await GetAllAsync<Project>(query);
    }

    public async Task<bool> ContributeToProject(InvestmentRequest investment)
    {
        string query = @"
            UPDATE projects
            SET current_funding = current_funding + @Amount
            WHERE project_id = @ProjectId;";

        return (await ExecuteAsync(query, new 
        {
            investment.ProjectId,
            investment.Amount
        })) == 1;
    }
    
    public async Task<bool> InsertProjectInvestor(InvestmentRequest investment)
    {
        string insertInvestmentQuery = @"
            INSERT INTO investments
            (investment_id, project_id, investor_name, amount)
            VALUES (gen_random_uuid(), @ProjectId, @Username, @Amount);";

        return (await ExecuteAsync(insertInvestmentQuery, new 
        {
            investment.ProjectId,
            investment.Username,
            investment.Amount
        })) == 1; 
    }

    public async Task<IEnumerable<UserInvestment>> GetUserInvestments(string username)
    {
        string userInvestments = @"SELECT project_id as ProjectId, amount from investments where investor_name = @username";
        return await GetAllAsync<UserInvestment>(userInvestments, new {username});
    }
    
    public async Task<Project?> GetProject(Guid projectId)
    {
        string query =  @"
        BEGIN;
        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        SELECT project_id as ProjectId, project_name as ProjectName, funding_goal as FundingGoal, description, current_funding as CurrentFunding FROM projects where project_id = @projectId;
        COMMIT";
        return await GetBySingleOrDefaultAsync<Project>(query, new {projectId});
    }
}
