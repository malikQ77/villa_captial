using System.Text.Json;
using System.Transactions;
using Core.Exceptions;
using Core.Messages;
using InvestmentService.DataAccess;
using InvestmentService.Models;
using PaymentService.Models;

namespace InvestmentService.BusinessLogic;

public class InvestmentServiceLogic
{
    private readonly InvestmentServiceRepository _investmentRepository;
    private readonly IServiceProvider _serviceProvider;

    public InvestmentServiceLogic(InvestmentServiceRepository investmentRepository, IServiceProvider serviceProvider)
    {
        _investmentRepository = investmentRepository;
        _serviceProvider = serviceProvider;
    }

    public async Task<CreateProjectResponse> CreateNewProject(Project project)
    {
        project.ProjectId = Guid.NewGuid();
        project.CurrentFunding = 0;

        var result = await _investmentRepository.CreateProject(project);

        return new CreateProjectResponse() { Status = result, ProjectId = project.ProjectId.Value };
    }

    public async Task<IEnumerable<Project>> ViewAllProjects()
    {
        return await _investmentRepository.GetAllProjects();
    }

    public async Task<InvestmentResponse> InvestInProject(InvestmentRequest investment)
    {
        using (var scope = _serviceProvider.CreateScope())
        {
            var messageHandler = scope.ServiceProvider.GetRequiredService<MessageHandler>();

            var balanceResponse = await messageHandler.PublishMessageAndWaitForResponse(
                new { Username = investment.Username, AmountRequested = investment.Amount },
                "balance_validation_exchange",
                "validate_balance",
                TimeSpan.FromSeconds(3)
            );

            var balanceValidationResult = JsonSerializer.Deserialize<BalanceValidationResult>(balanceResponse);

            if (balanceValidationResult?.IsValid != true)
                throw new VillaCapitalException(ExceptionDetails.InsufficientBalance);
            

            using (var transactionScope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                await _investmentRepository.ContributeToProject(investment);
                await _investmentRepository.InsertProjectInvestor(investment);
                 messageHandler.PublishMessage(
                    new BalanceDeductionRequest { Username = investment.Username, AmountToDeduct = investment.Amount },
                    "balance_deduction_exchange",
                    "reduce_balance"
                );
                 
                transactionScope.Complete();
                return new InvestmentResponse() { Status = true };
            }
        }
    }
}