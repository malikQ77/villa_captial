namespace InvestmentService;

using BusinessLogic;

public class RabbitMqListenerService : IHostedService
{
    private readonly IServiceProvider _serviceProvider;

    public RabbitMqListenerService(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        var scope = _serviceProvider.CreateScope();
        var investmentListeners = scope.ServiceProvider.GetRequiredService<InvestmentListeners>();
        investmentListeners.StartListeningForGetUserPortfolioRequests();
        investmentListeners.StartListeningForGetProjectByIdRequests();
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }
}