using System.Text;
using System.Text.Json;
using Core.Messages;
using InvestmentService.DataAccess;
using InvestmentService.Models;
using RabbitMQ.Client;
using Serilog;

namespace InvestmentService.BusinessLogic;

public class InvestmentListeners
{
    private readonly InvestmentServiceRepository _investmentServiceRepository;
    private readonly MessageHandler _messageHandler;
    private readonly IModel _channel;

    public InvestmentListeners(MessageHandler messageHandler, IModel channel, InvestmentServiceRepository investmentServiceRepository)
    {
        _messageHandler = messageHandler;
        _channel = channel;
        _investmentServiceRepository = investmentServiceRepository;
    }

    public void StartListeningForGetUserPortfolioRequests()
    {
        _messageHandler.ConsumeMessages("get_user_portfolio_queue", async (ea) =>
        {
            var messageBody = Encoding.UTF8.GetString(ea.Body.ToArray());
            var userPortfolioRequest = JsonSerializer.Deserialize<GetUserPortfolio>(messageBody);

            Log.Information($"Received get user portfolio for Username: {userPortfolioRequest.Username}");

            var portfolio = await _investmentServiceRepository.GetUserInvestments(userPortfolioRequest.Username);

            var replyTo = ea.BasicProperties.ReplyTo;
            var correlationId = ea.BasicProperties.CorrelationId;

            if (string.IsNullOrEmpty(replyTo))
            {
                throw new ArgumentNullException(nameof(replyTo), "ReplyTo cannot be null or empty.");
            }

            var responseBody = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(portfolio));

            var responseProperties = _channel.CreateBasicProperties();
            responseProperties.CorrelationId = correlationId;

            _channel.BasicPublish(exchange: "", routingKey: replyTo, basicProperties: responseProperties, body: responseBody);

           Log.Information($"get user portfolio response sent to ReplyTo queue: {replyTo}");
        });
    }
    
    public void StartListeningForGetProjectByIdRequests()
    {
        _messageHandler.ConsumeMessages("get_project_details_queue", async (ea) =>
        {
            var messageBody = Encoding.UTF8.GetString(ea.Body.ToArray());
            var projectByIdRequest = JsonSerializer.Deserialize<GetProjectInfoRequest>(messageBody);

            Log.Information($"Received get project by id for project: {projectByIdRequest.ProjectId}");

            var project = await _investmentServiceRepository.GetProject(projectByIdRequest.ProjectId);

            var replyTo = ea.BasicProperties.ReplyTo;
            var correlationId = ea.BasicProperties.CorrelationId;

            if (string.IsNullOrEmpty(replyTo))
            {
                throw new ArgumentNullException(nameof(replyTo), "ReplyTo cannot be null or empty.");
            }


            var responseBody = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(project));

            var responseProperties = _channel.CreateBasicProperties();
            responseProperties.CorrelationId = correlationId;

            _channel.BasicPublish(exchange: "", routingKey: replyTo, basicProperties: responseProperties, body: responseBody);

            Log.Information($"get project by id response sent to ReplyTo queue: {replyTo}");
        });
    }

}
