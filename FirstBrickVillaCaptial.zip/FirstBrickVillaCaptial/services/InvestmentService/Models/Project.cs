namespace InvestmentService.Models;


public class Project
{
    public Guid? ProjectId { get; set; }
    public string ProjectName { get; set; }
    public decimal? FundingGoal { get; set; }
    public string Description { get; set; }
    public decimal CurrentFunding { get; set; }
}

public class CreateProjectResponse
{
    public bool Status { get; set; }
    public Guid ProjectId { get; set; }
}

public class GetProjectInfoRequest
{
    public Guid ProjectId { get; set; }
}