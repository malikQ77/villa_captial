namespace InvestmentService.Models;

public class GetUserPortfolio
{
    public string Username { get; set; }
}