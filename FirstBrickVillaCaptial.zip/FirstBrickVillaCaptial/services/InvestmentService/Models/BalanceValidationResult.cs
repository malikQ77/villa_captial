namespace InvestmentService.Models;

public class BalanceValidationResult
{
    public bool IsValid { get; set; }
}