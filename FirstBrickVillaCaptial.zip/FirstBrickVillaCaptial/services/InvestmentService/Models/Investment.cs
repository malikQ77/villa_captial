namespace InvestmentService.Models;

public class InvestmentRequest
{
    public Guid ProjectId { get; set; }
    public string Username { get; set; }
    public decimal Amount { get; set; }
}

public class InvestmentResponse
{
 public bool Status { get; set; }   
}


public class UserInvestment
{
    public Guid ProjectId { get; set; }
    public decimal Amount { get; set; }
}