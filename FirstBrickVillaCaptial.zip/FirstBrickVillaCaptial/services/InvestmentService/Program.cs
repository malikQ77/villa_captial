using Core.ServicesInitializer;
using InvestmentService;
using InvestmentService.BusinessLogic;
using InvestmentService.DataAccess;

string appSettingsPath = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
string secretsPath = Path.Combine(Directory.GetCurrentDirectory(), "secrets.json");


var builder = WebApplication.CreateBuilder(args);
ServiceInitializer.Initialize<AppConfigs>(builder, appSettingsPath, secretsPath);

builder.Services.AddSingleton<InvestmentServiceLogic>();
builder.Services.AddSingleton<InvestmentServiceRepository>();
builder.Services.AddTransient<InvestmentListeners>();
builder.Services.AddHostedService<RabbitMqListenerService>();

var app = builder.Build();
ServiceInitializer.Configure(app);