using Core.ServicesInitializer;
using PortfolioService.BusinessLogic;


string appSettingsPath = Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json");
string secretsPath = Path.Combine(Directory.GetCurrentDirectory(), "secrets.json");


var builder = WebApplication.CreateBuilder(args);
ServiceInitializer.Initialize<AppConfigs>(builder, appSettingsPath, secretsPath);

builder.Services.AddSingleton<PortfolioServiceLogic>();

var app = builder.Build();
ServiceInitializer.Configure(app);