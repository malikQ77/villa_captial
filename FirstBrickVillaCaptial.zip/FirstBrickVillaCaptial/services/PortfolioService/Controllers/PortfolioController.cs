using Microsoft.AspNetCore.Mvc;
using PortfolioService.BusinessLogic;

namespace PortfolioService.Controllers;

[ApiController]
[Route("v1/[controller]")]
public class PortfolioController : ControllerBase
{
    private readonly PortfolioServiceLogic _portfolioServiceLogic;

    public PortfolioController(PortfolioServiceLogic portfolioServiceLogic)
    {
        _portfolioServiceLogic = portfolioServiceLogic;
    }

    [HttpGet("/v1/portfolio")]
    public async Task<IActionResult> GetUserPortfolio([FromQuery] string username)
    {
        return Ok(await _portfolioServiceLogic.GetUserPortfolio(username));
    }

    [HttpGet("/v1/portfolio/{projectId}")]
    public async Task<IActionResult> GetProjectDetails([FromRoute] Guid projectId)
    {
        return Ok(await _portfolioServiceLogic.GetProjectDetails(projectId));
    }
}
