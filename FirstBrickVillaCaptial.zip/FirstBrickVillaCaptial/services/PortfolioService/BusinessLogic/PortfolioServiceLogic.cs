using System.Text.Json;
using Core.Exceptions;
using Core.Messages;
using PortfolioService.Models;

namespace PortfolioService.BusinessLogic;

public class PortfolioServiceLogic
{
    private readonly IServiceProvider _serviceProvider;

    public PortfolioServiceLogic(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }
    
    public async Task<List<Portfolio>> GetUserPortfolio(string username)
    {
        using (var scope = _serviceProvider.CreateScope())
        {
            var messageHandler = scope.ServiceProvider.GetRequiredService<MessageHandler>();

            var portfolioResponse = await messageHandler.PublishMessageAndWaitForResponse(
                new { Username = username },
                "user_portfolio_exchange",
                "get_user_portfolio",
                TimeSpan.FromSeconds(3)
            );

            var portfolio = JsonSerializer.Deserialize<List<Portfolio>>(portfolioResponse);

            if (!portfolio!.Any())
                throw new VillaCapitalException(ExceptionDetails.DataNotAvailable);


            return portfolio;
        }
    }

    public async Task<dynamic> GetProjectDetails(Guid projectId)
    {
        using (var scope = _serviceProvider.CreateScope())
        {
            var messageHandler = scope.ServiceProvider.GetRequiredService<MessageHandler>();

            var projectResponse = await messageHandler.PublishMessageAndWaitForResponse(
                new { ProjectId = projectId },
                "get_project_details_exchange",
                "get_project_details",
                TimeSpan.FromSeconds(3)
            );

            var project = JsonSerializer.Deserialize<Project>(projectResponse);

            if (project is null)
                throw new VillaCapitalException(ExceptionDetails.DataNotAvailable);


            return project;
        }
    }
}