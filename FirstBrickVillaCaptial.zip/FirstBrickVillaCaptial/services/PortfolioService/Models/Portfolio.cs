namespace PortfolioService.Models;

public class Portfolio
{
    public Guid ProjectId { get; set; }
    public decimal Amount { get; set; }
}