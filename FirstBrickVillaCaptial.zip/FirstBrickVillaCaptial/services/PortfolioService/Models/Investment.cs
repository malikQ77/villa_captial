namespace PortfolioService.Models;

public class Investment
{
    public Guid ProjectId { get; set; }
    public decimal Amount { get; set; }
}

