namespace PortfolioService.Models;


public class Project
{
    public string ProjectName { get; set; }
    public decimal? FundingGoal { get; set; }
    public string Description { get; set; }
    public decimal CurrentFunding { get; set; }
}