-- Database: villa_captial_db

-- DROP DATABASE IF EXISTS villa_captial_db;

CREATE DATABASE villa_captial_db
    WITH
    OWNER = villa_captial_admin
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;

GRANT TEMPORARY, CONNECT ON DATABASE villa_captial_db TO PUBLIC;

GRANT ALL ON DATABASE villa_captial_db TO villa_captial_admin;



-- SCHEMA: public

-- DROP SCHEMA IF EXISTS public ;

CREATE SCHEMA IF NOT EXISTS public
    AUTHORIZATION malik;

COMMENT ON SCHEMA public
    IS 'standard public schema';

GRANT ALL ON SCHEMA public TO PUBLIC;

GRANT ALL ON SCHEMA public TO malik;


-- Table: public.users

-- DROP TABLE IF EXISTS public.users;

CREATE TABLE IF NOT EXISTS public.users
(
    username character varying(100) COLLATE pg_catalog."default" NOT NULL,
    password character varying(255) COLLATE pg_catalog."default",
    full_name character varying(255) COLLATE pg_catalog."default",
    is_active boolean NOT NULL DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT username_pk PRIMARY KEY (username)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.users
    OWNER to villa_captial_admin;
-- Index: idx_username

-- DROP INDEX IF EXISTS public.idx_username;

CREATE UNIQUE INDEX IF NOT EXISTS idx_username
    ON public.users USING btree
    (username COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;


-- Table: public.users_balance

-- DROP TABLE IF EXISTS public.users_balance;

CREATE TABLE IF NOT EXISTS public.users_balance
(
    username character varying(255) COLLATE pg_catalog."default" NOT NULL,
    balance numeric(18,2) NOT NULL DEFAULT 0,
    CONSTRAINT users_balance_pkey PRIMARY KEY (username)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.users_balance
    OWNER to villa_captial_admin;


-- Table: public.transactions

-- DROP TABLE IF EXISTS public.transactions;

CREATE TABLE IF NOT EXISTS public.transactions
(
    transaction_id uuid NOT NULL DEFAULT gen_random_uuid(),
    username character varying(255) COLLATE pg_catalog."default" NOT NULL,
    amount numeric(18,2) NOT NULL,
    transaction_date timestamp without time zone NOT NULL DEFAULT now(),
    CONSTRAINT transactions_pkey PRIMARY KEY (transaction_id),
    CONSTRAINT fk_users_balance FOREIGN KEY (username)
        REFERENCES public.users_balance (username) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.transactions
    OWNER to villa_captial_admin;


	
-- Table: public.tokens_management

-- DROP TABLE IF EXISTS public.tokens_management;

CREATE TABLE IF NOT EXISTS public.tokens_management
(
    token_id uuid NOT NULL,
    username character varying(100) COLLATE pg_catalog."default" NOT NULL,
    is_active boolean NOT NULL DEFAULT true,
    created_at timestamp without time zone NOT NULL DEFAULT now(),
    deactivation_at timestamp without time zone,
    CONSTRAINT tokens_management_pkey PRIMARY KEY (token_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.tokens_management
    OWNER to villa_captial_admin;
-- Index: tokens_username

-- DROP INDEX IF EXISTS public.tokens_username;

CREATE INDEX IF NOT EXISTS tokens_username
    ON public.tokens_management USING btree
    (username COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
	


-- Table: public.projects

-- DROP TABLE IF EXISTS public.projects;

CREATE TABLE IF NOT EXISTS public.projects
(
    project_id uuid NOT NULL,
    project_name character varying(255) COLLATE pg_catalog."default" NOT NULL,
    funding_goal numeric(18,2) NOT NULL,
    description text COLLATE pg_catalog."default",
    current_funding numeric(18,2) NOT NULL DEFAULT 0,
    CONSTRAINT projects_pkey PRIMARY KEY (project_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.projects
    OWNER to villa_captial_admin;


-- Table: public.investments

-- DROP TABLE IF EXISTS public.investments;

CREATE TABLE IF NOT EXISTS public.investments
(
    investment_id uuid NOT NULL DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL,
    investor_name character varying(255) COLLATE pg_catalog."default" NOT NULL,
    amount numeric(18,2) NOT NULL,
    invested_at timestamp without time zone NOT NULL DEFAULT now(),
    CONSTRAINT investments_pkey PRIMARY KEY (investment_id),
    CONSTRAINT fk_project FOREIGN KEY (project_id)
        REFERENCES public.projects (project_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.investments
    OWNER to villa_captial_admin;


